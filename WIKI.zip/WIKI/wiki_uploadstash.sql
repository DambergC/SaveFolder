-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `uploadstash`
--

DROP TABLE IF EXISTS `uploadstash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uploadstash` (
  `us_id` int unsigned NOT NULL AUTO_INCREMENT,
  `us_user` int unsigned NOT NULL,
  `us_key` varbinary(255) NOT NULL,
  `us_orig_path` varbinary(255) NOT NULL,
  `us_path` varbinary(255) NOT NULL,
  `us_source_type` varbinary(50) DEFAULT NULL,
  `us_timestamp` binary(14) NOT NULL,
  `us_status` varbinary(50) NOT NULL,
  `us_chunk_inx` int unsigned DEFAULT NULL,
  `us_props` blob,
  `us_size` int unsigned NOT NULL,
  `us_sha1` varbinary(31) NOT NULL,
  `us_mime` varbinary(255) DEFAULT NULL,
  `us_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE','3D') DEFAULT NULL,
  `us_image_width` int unsigned DEFAULT NULL,
  `us_image_height` int unsigned DEFAULT NULL,
  `us_image_bits` smallint unsigned DEFAULT NULL,
  PRIMARY KEY (`us_id`),
  UNIQUE KEY `us_key` (`us_key`),
  KEY `us_user` (`us_user`),
  KEY `us_timestamp` (`us_timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploadstash`
--

LOCK TABLES `uploadstash` WRITE;
/*!40000 ALTER TABLE `uploadstash` DISABLE KEYS */;
INSERT INTO `uploadstash` VALUES (3,1,_binary '18cc0i4h0cxs.o1pdst.1.tmp',_binary 'C:\\Windows\\Temp\\phpE1F9.tmp',_binary 'mwrepo://local/temp/e/e4/20210517071716!phpE1F9.tmp',_binary 'file',_binary '20210517071716',_binary 'finished',NULL,_binary 'a:12:{s:5:\"width\";i:453;s:6:\"height\";i:115;s:4:\"bits\";i:8;s:10:\"fileExists\";b:1;s:4:\"size\";i:6217;s:9:\"file-mime\";s:9:\"image/png\";s:10:\"major_mime\";s:5:\"image\";s:10:\"minor_mime\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";s:4:\"sha1\";s:31:\"3bgig7djnlwvihnhky76fw850v8rikd\";s:8:\"metadata\";s:268:\"a:6:{s:10:\"frameCount\";i:0;s:9:\"loopCount\";i:1;s:8:\"duration\";d:0;s:8:\"bitDepth\";i:8;s:9:\"colorType\";s:16:\"truecolour-alpha\";s:8:\"metadata\";a:4:{s:11:\"XResolution\";s:8:\"3779/100\";s:11:\"YResolution\";s:8:\"3779/100\";s:14:\"ResolutionUnit\";i:3;s:15:\"_MW_PNG_VERSION\";i:1;}}\";s:10:\"media_type\";s:6:\"BITMAP\";}',6217,_binary '3bgig7djnlwvihnhky76fw850v8rikd',_binary 'image/png',_binary 'BITMAP',453,115,8),(4,1,_binary '18cceel57ugk.ufzu24.1.tmp',_binary 'C:\\Windows\\Temp\\php1C1B.tmp',_binary 'mwrepo://local/temp/7/7d/20210517101850!php1C1B.tmp',_binary 'file',_binary '20210517101850',_binary 'finished',NULL,_binary 'a:12:{s:5:\"width\";i:284;s:6:\"height\";i:126;s:4:\"bits\";i:8;s:10:\"fileExists\";b:1;s:4:\"size\";i:8588;s:9:\"file-mime\";s:9:\"image/png\";s:10:\"major_mime\";s:5:\"image\";s:10:\"minor_mime\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";s:4:\"sha1\";s:31:\"bbp0f5bjyuzxm9jyer9xlc9j154pi2v\";s:8:\"metadata\";s:174:\"a:6:{s:10:\"frameCount\";i:0;s:9:\"loopCount\";i:1;s:8:\"duration\";d:0;s:8:\"bitDepth\";i:8;s:9:\"colorType\";s:16:\"truecolour-alpha\";s:8:\"metadata\";a:1:{s:15:\"_MW_PNG_VERSION\";i:1;}}\";s:10:\"media_type\";s:6:\"BITMAP\";}',8588,_binary 'bbp0f5bjyuzxm9jyer9xlc9j154pi2v',_binary 'image/png',_binary 'BITMAP',284,126,8);
/*!40000 ALTER TABLE `uploadstash` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:54
