-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `watchlist`
--

DROP TABLE IF EXISTS `watchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watchlist` (
  `wl_id` int unsigned NOT NULL AUTO_INCREMENT,
  `wl_user` int unsigned NOT NULL,
  `wl_namespace` int NOT NULL DEFAULT '0',
  `wl_title` varbinary(255) NOT NULL DEFAULT '',
  `wl_notificationtimestamp` binary(14) DEFAULT NULL,
  PRIMARY KEY (`wl_id`),
  UNIQUE KEY `wl_user` (`wl_user`,`wl_namespace`,`wl_title`),
  KEY `wl_namespace_title` (`wl_namespace`,`wl_title`),
  KEY `wl_user_notificationtimestamp` (`wl_user`,`wl_notificationtimestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchlist`
--

LOCK TABLES `watchlist` WRITE;
/*!40000 ALTER TABLE `watchlist` DISABLE KEYS */;
INSERT INTO `watchlist` VALUES (1,1,0,_binary 'Main_Page',NULL),(2,1,1,_binary 'Main_Page',NULL),(3,1,8,_binary 'Sidebar',NULL),(4,1,9,_binary 'Sidebar',NULL),(5,1,0,_binary 'InstruktionDrift',NULL),(6,1,1,_binary 'InstruktionDrift',NULL),(7,1,0,_binary 'InstruktionSpecial',NULL),(8,1,1,_binary 'InstruktionSpecial',NULL),(9,1,0,_binary 'Presentationsskarmar',NULL),(10,1,1,_binary 'Presentationsskarmar',NULL),(11,1,0,_binary 'Outlooksignaturer',_binary '20231003122822'),(12,1,1,_binary 'Outlooksignaturer',NULL),(13,1,0,_binary 'Instruktion_-_Drift',NULL),(14,1,1,_binary 'Instruktion_-_Drift',NULL),(15,1,0,_binary 'Instruktion_-_Special',NULL),(16,1,1,_binary 'Instruktion_-_Special',NULL),(17,1,0,_binary 'Användar_-_Bilder_AD',NULL),(18,1,1,_binary 'Användar_-_Bilder_AD',NULL),(19,1,6,_binary 'Image2019-8-26_15-51-43.png',NULL),(20,1,7,_binary 'Image2019-8-26_15-51-43.png',NULL),(21,1,0,_binary 'AnyConnect_-_MAC',NULL),(22,1,1,_binary 'AnyConnect_-_MAC',NULL),(23,1,0,_binary 'Canon_OCÉ',NULL),(24,1,1,_binary 'Canon_OCÉ',NULL),(25,1,0,_binary 'Change_default_printer',NULL),(26,1,1,_binary 'Change_default_printer',NULL),(27,1,6,_binary 'Kb00003-01.png',NULL),(28,1,7,_binary 'Kb00003-01.png',NULL),(29,1,6,_binary 'Kb00003-02.png',NULL),(30,1,7,_binary 'Kb00003-02.png',NULL),(31,1,6,_binary 'Kb00003-03.png',NULL),(32,1,7,_binary 'Kb00003-03.png',NULL),(33,1,0,_binary 'DirectAccess_Client_Troubleshooting',_binary '20230130111201'),(34,1,1,_binary 'DirectAccess_Client_Troubleshooting',NULL),(35,1,0,_binary 'Dubbla_skärmar_på_fjärrskrivbord',NULL),(36,1,1,_binary 'Dubbla_skärmar_på_fjärrskrivbord',NULL),(37,1,6,_binary 'Dubblaskärmar1.png',NULL),(38,1,7,_binary 'Dubblaskärmar1.png',NULL),(39,1,6,_binary 'Dubblaskärmar2.png',NULL),(40,1,7,_binary 'Dubblaskärmar2.png',NULL),(41,1,6,_binary 'Dubblaskärmar3.png',NULL),(42,1,7,_binary 'Dubblaskärmar3.png',NULL),(43,1,0,_binary 'Lägga_till_användare_i_TRIVAS',NULL),(44,1,1,_binary 'Lägga_till_användare_i_TRIVAS',NULL),(45,1,0,_binary 'Panda,_avblockera_program',NULL),(46,1,1,_binary 'Panda,_avblockera_program',NULL),(47,1,0,_binary 'R-Card_M5',NULL),(48,1,1,_binary 'R-Card_M5',NULL),(49,1,6,_binary 'M5-card.png',NULL),(50,1,7,_binary 'M5-card.png',NULL),(51,1,6,_binary 'Revitfontfel.jpg',NULL),(52,1,7,_binary 'Revitfontfel.jpg',NULL),(53,1,6,_binary 'Revitfontfel2.jpg',NULL),(54,1,7,_binary 'Revitfontfel2.jpg',NULL),(55,1,6,_binary 'Revitfontfel3.jpg',NULL),(56,1,7,_binary 'Revitfontfel3.jpg',NULL),(57,1,0,_binary 'Revit_Fontfel',NULL),(58,1,1,_binary 'Revit_Fontfel',NULL),(59,1,0,_binary 'Rutin_för_när_någon_slutar',NULL),(60,1,1,_binary 'Rutin_för_när_någon_slutar',NULL),(61,1,6,_binary 'Autosvar2.png',NULL),(62,1,7,_binary 'Autosvar2.png',NULL),(63,1,6,_binary 'Autosvar3.png',NULL),(64,1,7,_binary 'Autosvar3.png',NULL),(65,1,6,_binary 'Autosvar4.png',NULL),(66,1,7,_binary 'Autosvar4.png',NULL),(67,1,0,_binary 'Lägga_in_autosvar_åt_användare',NULL),(68,1,1,_binary 'Lägga_in_autosvar_åt_användare',NULL),(69,1,6,_binary 'Autosvar1.png',NULL),(70,1,7,_binary 'Autosvar1.png',NULL),(71,1,0,_binary 'Scanners_TH',_binary '20210602085631'),(72,1,1,_binary 'Scanners_TH',NULL),(73,1,0,_binary 'Teams-TH',NULL),(74,1,1,_binary 'Teams-TH',NULL),(75,1,0,_binary 'Trivselhus_lösenordspolicy',NULL),(76,1,1,_binary 'Trivselhus_lösenordspolicy',NULL),(77,1,6,_binary 'Tadmin_fel.PNG',NULL),(78,1,7,_binary 'Tadmin_fel.PNG',NULL),(79,1,6,_binary 'T-admin_id.png',NULL),(80,1,7,_binary 'T-admin_id.png',NULL),(81,1,0,_binary 'T-admin,_\"Id\"_fel',NULL),(82,1,1,_binary 'T-admin,_\"Id\"_fel',NULL),(83,1,0,_binary 'TAdmin_och_TKalk_felmeddelanden_vid_uppstart',NULL),(84,1,1,_binary 'TAdmin_och_TKalk_felmeddelanden_vid_uppstart',NULL),(85,1,0,_binary 'T-system_Logga_ut_användare',NULL),(86,1,1,_binary 'T-system_Logga_ut_användare',NULL),(87,1,6,_binary 'Fjärrstyrning_av_klient_på_nya_RDS-klustret.docx',NULL),(88,1,7,_binary 'Fjärrstyrning_av_klient_på_nya_RDS-klustret.docx',NULL),(91,1,6,_binary 'Image2019-8-26_15-52-49.png',NULL),(92,1,7,_binary 'Image2019-8-26_15-52-49.png',NULL),(93,1,6,_binary 'Image2019-8-27_10-32-7.png',NULL),(94,1,7,_binary 'Image2019-8-27_10-32-7.png',NULL),(95,1,6,_binary 'Image2019-8-27_10-34-22.png',NULL),(96,1,7,_binary 'Image2019-8-27_10-34-22.png',NULL),(97,1,8,_binary 'Common.css',NULL),(98,1,9,_binary 'Common.css',NULL),(99,1,8,_binary 'Timeless.css',NULL),(100,1,9,_binary 'Timeless.css',NULL),(101,1,14,_binary 'Active_Directory',NULL),(102,1,15,_binary 'Active_Directory',NULL),(103,1,14,_binary 'Skrivare',NULL),(104,1,15,_binary 'Skrivare',NULL),(105,1,14,_binary 'Utskrifter',NULL),(106,1,15,_binary 'Utskrifter',NULL),(107,1,14,_binary 'Uppkoppling',NULL),(108,1,15,_binary 'Uppkoppling',NULL),(109,1,0,_binary 'Install_printer',NULL),(110,1,1,_binary 'Install_printer',NULL),(111,1,6,_binary 'Newuser3.png',NULL),(112,1,7,_binary 'Newuser3.png',NULL),(113,1,6,_binary 'Newuser2.png',NULL),(114,1,7,_binary 'Newuser2.png',NULL),(115,1,6,_binary 'Newuser4.png',NULL),(116,1,7,_binary 'Newuser4.png',NULL),(117,1,6,_binary 'Newuser5.png',NULL),(118,1,7,_binary 'Newuser5.png',NULL),(119,1,6,_binary 'Newuser6.png',NULL),(120,1,7,_binary 'Newuser6.png',NULL),(121,1,6,_binary 'Newuser1.png',NULL),(122,1,7,_binary 'Newuser1.png',NULL),(123,1,0,_binary 'New_User_creation_TH',NULL),(124,1,1,_binary 'New_User_creation_TH',NULL),(125,1,0,_binary 'Ny_användare_T-program',NULL),(126,1,1,_binary 'Ny_användare_T-program',NULL),(127,1,0,_binary 'Ny_användare_Checklist',_binary '20220905083501'),(128,1,1,_binary 'Ny_användare_Checklist',NULL),(129,1,0,_binary 'Remote_Desktop_TH',NULL),(130,1,1,_binary 'Remote_Desktop_TH',NULL),(131,1,0,_binary 'GPO_-_RemoteApp',NULL),(132,1,1,_binary 'GPO_-_RemoteApp',NULL),(133,1,0,_binary 'ODBC-Koppling_på_TH-MGT01',NULL),(134,1,1,_binary 'ODBC-Koppling_på_TH-MGT01',NULL),(135,1,6,_binary 'Odbc4.PNG',NULL),(136,1,7,_binary 'Odbc4.PNG',NULL),(137,1,6,_binary 'Odbc3.PNG',NULL),(138,1,7,_binary 'Odbc3.PNG',NULL),(139,1,6,_binary 'Odbc2.PNG',NULL),(140,1,7,_binary 'Odbc2.PNG',NULL),(141,1,6,_binary 'Odbc1.PNG',NULL),(142,1,7,_binary 'Odbc1.PNG',NULL),(143,1,0,_binary 'Installation_av_Tstart_(fjärrapp)',NULL),(144,1,1,_binary 'Installation_av_Tstart_(fjärrapp)',NULL),(145,1,0,_binary 'PDFfill',NULL),(146,1,1,_binary 'PDFfill',NULL),(147,1,0,_binary 'Kan_inte_spara_filer_i_Grupphusportalen',NULL),(148,1,1,_binary 'Kan_inte_spara_filer_i_Grupphusportalen',NULL),(149,1,0,_binary 'Telefonsvarare/Röstbrevlåda',NULL),(150,1,1,_binary 'Telefonsvarare/Röstbrevlåda',NULL),(151,1,0,_binary 'Pyramid_TH',NULL),(152,1,1,_binary 'Pyramid_TH',NULL),(153,1,6,_binary 'Sign8.png',NULL),(154,1,7,_binary 'Sign8.png',NULL),(155,1,6,_binary 'Sign7.png',NULL),(156,1,7,_binary 'Sign7.png',NULL),(157,1,6,_binary 'Sign6.png',NULL),(158,1,7,_binary 'Sign6.png',NULL),(159,1,6,_binary 'Sign5.png',NULL),(160,1,7,_binary 'Sign5.png',NULL),(161,1,6,_binary 'Sign4.png',NULL),(162,1,7,_binary 'Sign4.png',NULL),(163,1,6,_binary 'Sign3.png',NULL),(164,1,7,_binary 'Sign3.png',NULL),(165,1,6,_binary 'Sign2.png',NULL),(166,1,7,_binary 'Sign2.png',NULL),(167,1,6,_binary 'Sign1.png',NULL),(168,1,7,_binary 'Sign1.png',NULL),(169,1,6,_binary 'Sign11.png',NULL),(170,1,7,_binary 'Sign11.png',NULL),(171,1,6,_binary 'Sign10.png',NULL),(172,1,7,_binary 'Sign10.png',NULL),(173,1,6,_binary 'Sign9.png',NULL),(174,1,7,_binary 'Sign9.png',NULL),(175,1,0,_binary 'Antivirus_Panda',NULL),(176,1,1,_binary 'Antivirus_Panda',NULL),(177,1,0,_binary 'Webroot',NULL),(178,1,1,_binary 'Webroot',NULL),(179,1,0,_binary 'Arbetsplats_Datormodeller',NULL),(180,1,1,_binary 'Arbetsplats_Datormodeller',NULL),(181,1,0,_binary 'Azure_Office_365_Tenant',NULL),(182,1,1,_binary 'Azure_Office_365_Tenant',NULL),(183,1,0,_binary 'Azure_Skype_for_Business',NULL),(184,1,1,_binary 'Azure_Skype_for_Business',NULL),(185,1,0,_binary 'Azure_Yammer',NULL),(186,1,1,_binary 'Azure_Yammer',NULL),(187,3,2,_binary 'THSupport',_binary '20210628072808'),(188,3,3,_binary 'THSupport',NULL),(189,1,0,_binary 'Script_to_update_MaintanceWindows',NULL),(190,1,1,_binary 'Script_to_update_MaintanceWindows',NULL),(191,1,0,_binary 'Revit_ny_licens',NULL),(192,1,1,_binary 'Revit_ny_licens',NULL);
/*!40000 ALTER TABLE `watchlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:53
