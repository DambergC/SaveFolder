-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `externallinks`
--

DROP TABLE IF EXISTS `externallinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `externallinks` (
  `el_id` int unsigned NOT NULL AUTO_INCREMENT,
  `el_from` int unsigned NOT NULL DEFAULT '0',
  `el_to` blob NOT NULL,
  `el_index` blob NOT NULL,
  `el_index_60` varbinary(60) NOT NULL,
  PRIMARY KEY (`el_id`),
  KEY `el_from` (`el_from`,`el_to`(40)),
  KEY `el_to` (`el_to`(60),`el_from`),
  KEY `el_index` (`el_index`(60)),
  KEY `el_index_60` (`el_index_60`,`el_id`),
  KEY `el_from_index_60` (`el_from`,`el_index_60`,`el_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `externallinks`
--

LOCK TABLES `externallinks` WRITE;
/*!40000 ALTER TABLE `externallinks` DISABLE KEYS */;
INSERT INTO `externallinks` VALUES (1,12,_binary 'https://www.cisco.com/c/en/us/td/docs/security/vpn_client/anyconnect/anyconnect47/feature/guide/anyconnect47features.html#pgfId-63847',_binary 'https://com.cisco.www./c/en/us/td/docs/security/vpn_client/anyconnect/anyconnect47/feature/guide/anyconnect47features.html#pgfId-63847',_binary 'https://com.cisco.www./c/en/us/td/docs/security/vpn_client/a'),(2,18,_binary 'https://www.microsoft.com/en-us/download/details.aspx?id=41938',_binary 'https://com.microsoft.www./en-us/download/details.aspx?id=41938',_binary 'https://com.microsoft.www./en-us/download/details.aspx?id=41'),(3,23,_binary 'http://mailto:henrik.lamme@trivselhus.se',_binary 'http://se.trivselhus./',_binary 'http://se.trivselhus./'),(4,25,_binary 'https://www.rco.se/support/r-card-m5-programvara/',_binary 'https://se.rco.www./support/r-card-m5-programvara/',_binary 'https://se.rco.www./support/r-card-m5-programvara/'),(11,65,_binary 'https://kb.sodra.com/display/TRIV/Installation+for+iGrid',_binary 'https://com.sodra.kb./display/TRIV/Installation+for+iGrid',_binary 'https://com.sodra.kb./display/TRIV/Installation+for+iGrid'),(12,89,_binary 'https://accounts.pandasecurity.com/web/Account/Login?ReturnUrl=/web/?wtrealm%3Dhttps%253A%252F%252Fwg.aether.pandasecurity.com%26wctx%3DWsFedOwinState%253DM5TMtwNv5cVOkngOrx90y6NRVWO33MTWqETrG3c5byzcf6ROp8CIkWNdGWi_yPD5PaqKk0vN3uMj5nV0Y7JLkOtXOYO-vxCw34cM0PI4Bqyk2gKBUv6nc9NiZ9KywPxjhzcRZw%26wa%3Dwsignin1.0',_binary 'https://com.pandasecurity.accounts./web/Account/Login?ReturnUrl=/web/?wtrealm%3Dhttps%253A%252F%252Fwg.aether.pandasecurity.com%26wctx%3DWsFedOwinState%253DM5TMtwNv5cVOkngOrx90y6NRVWO33MTWqETrG3c5byzcf6ROp8CIkWNdGWi_yPD5PaqKk0vN3uMj5nV0Y7JLkOtXOYO-vxCw34cM0PI4Bqyk2gKBUv6nc9NiZ9KywPxjhzcRZw%26wa%3Dwsignin1.0',_binary 'https://com.pandasecurity.accounts./web/Account/Login?Return'),(13,96,_binary 'https://agacad.com/support/network-license-activation#how-to-update-reactivate-network-licence',_binary 'https://com.agacad./support/network-license-activation#how-to-update-reactivate-network-licence',_binary 'https://com.agacad./support/network-license-activation#how-t'),(14,37,_binary 'https://webmail.trivselhus.se/ecp/',_binary 'https://se.trivselhus.webmail./ecp/',_binary 'https://se.trivselhus.webmail./ecp/'),(15,65,_binary 'https://outlook.office365.com/powershell-liveid/',_binary 'https://com.office365.outlook./powershell-liveid/',_binary 'https://com.office365.outlook./powershell-liveid/'),(16,65,_binary 'https://ps.compliance.protection.outlook.com/powershell-liveid/',_binary 'https://com.outlook.protection.compliance.ps./powershell-liveid/',_binary 'https://com.outlook.protection.compliance.ps./powershell-liv');
/*!40000 ALTER TABLE `externallinks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:54
