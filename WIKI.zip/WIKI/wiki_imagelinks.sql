-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `imagelinks`
--

DROP TABLE IF EXISTS `imagelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagelinks` (
  `il_from` int unsigned NOT NULL DEFAULT '0',
  `il_to` varbinary(255) NOT NULL DEFAULT '',
  `il_from_namespace` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`il_from`,`il_to`),
  KEY `il_to` (`il_to`,`il_from`),
  KEY `il_backlinks_namespace` (`il_from_namespace`,`il_to`,`il_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagelinks`
--

LOCK TABLES `imagelinks` WRITE;
/*!40000 ALTER TABLE `imagelinks` DISABLE KEYS */;
INSERT INTO `imagelinks` VALUES (35,_binary 'Autosvar1.png',0),(35,_binary 'Autosvar2.png',0),(35,_binary 'Autosvar3.png',0),(35,_binary 'Autosvar4.png',0),(19,_binary 'Dubblaskärmar1.png',0),(19,_binary 'Dubblaskärmar2.png',0),(19,_binary 'Dubblaskärmar3.png',0),(44,_binary 'Fjärrstyrning_av_klient_på_nya_RDS-klustret.docx',0),(11,_binary 'Image2019-8-26_15-51-43.png',0),(11,_binary 'Image2019-8-26_15-52-49.png',0),(11,_binary 'Image2019-8-27_10-32-7.png',0),(11,_binary 'Image2019-8-27_10-34-22.png',0),(14,_binary 'Kb00003-01.png',0),(14,_binary 'Kb00003-02.png',0),(14,_binary 'Kb00003-03.png',0),(25,_binary 'M5-card.png',0),(63,_binary 'Newuser1.png',0),(63,_binary 'Newuser2.png',0),(63,_binary 'Newuser3.png',0),(63,_binary 'Newuser4.png',0),(63,_binary 'Newuser5.png',0),(63,_binary 'Newuser6.png',0),(68,_binary 'Odbc1.PNG',0),(68,_binary 'Odbc2.PNG',0),(68,_binary 'Odbc3.PNG',0),(68,_binary 'Odbc4.PNG',0),(30,_binary 'Revitfontfel.jpg',0),(30,_binary 'Revitfontfel2.jpg',0),(30,_binary 'Revitfontfel3.jpg',0),(6,_binary 'Sign1.png',0),(6,_binary 'Sign2.png',0),(6,_binary 'Sign3.png',0),(6,_binary 'Sign4.png',0),(6,_binary 'Sign5.png',0),(6,_binary 'Sign6.png',0),(6,_binary 'Sign7.png',0),(42,_binary 'T-admin_id.png',0),(42,_binary 'Tadmin_fel.PNG',0);
/*!40000 ALTER TABLE `imagelinks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:54
