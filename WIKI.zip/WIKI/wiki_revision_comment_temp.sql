-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `revision_comment_temp`
--

DROP TABLE IF EXISTS `revision_comment_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revision_comment_temp` (
  `revcomment_rev` int unsigned NOT NULL,
  `revcomment_comment_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`revcomment_rev`,`revcomment_comment_id`),
  UNIQUE KEY `revcomment_rev` (`revcomment_rev`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revision_comment_temp`
--

LOCK TABLES `revision_comment_temp` WRITE;
/*!40000 ALTER TABLE `revision_comment_temp` DISABLE KEYS */;
INSERT INTO `revision_comment_temp` VALUES (1,1),(2,1),(3,2),(4,1),(5,3),(6,4),(7,5),(8,6),(9,1),(10,1),(11,1),(12,7),(16,10),(17,1),(18,11),(19,1),(20,1),(22,1),(23,1),(24,1),(25,13),(26,1),(27,14),(28,1),(29,15),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,16),(43,1),(44,17),(45,1),(46,1),(47,1),(48,1),(49,1),(50,18),(51,1),(52,1),(53,19),(54,20),(55,1),(56,1),(57,1),(58,1),(59,1),(60,21),(61,22),(62,1),(63,1),(64,1),(65,23),(66,1),(67,1),(68,24),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,25),(76,26),(77,1),(78,1),(79,27),(80,1),(81,28),(82,29),(83,1),(84,1),(85,1),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1),(93,1),(94,1),(95,30),(96,1),(97,1),(98,1),(99,1),(100,1),(101,1),(102,1),(103,1),(104,1),(105,1),(106,1),(107,1),(108,1),(109,1),(110,1),(111,1),(112,1),(113,1),(114,1),(115,1),(116,1),(117,1),(118,1),(119,1),(120,1),(121,1),(122,1),(123,1),(124,1),(125,1),(126,31),(127,1),(128,1),(129,1),(130,1),(131,32),(132,1),(133,1),(134,1),(135,1),(136,1),(137,1),(138,1),(139,33),(141,1),(142,1),(143,36),(144,37),(145,1),(146,1),(147,1),(148,38),(149,1),(150,1),(151,1),(152,1),(153,1),(154,1),(155,39),(156,40),(157,41),(158,1),(159,42),(160,43),(161,44),(162,45),(163,45),(164,45),(165,45),(166,1),(167,1),(168,46),(169,47),(170,48),(171,49),(172,50),(173,45),(174,45),(175,45),(176,45),(177,45),(178,45),(179,45),(180,45),(181,45),(182,45),(183,45),(184,1),(185,1),(186,1),(187,51),(188,52),(189,53),(190,54),(191,55),(192,56),(193,1),(194,1),(195,1),(196,57),(197,58),(198,1),(199,59),(200,1),(201,1),(202,1),(203,60),(204,61),(205,62),(206,1),(207,1),(208,1),(209,1),(210,1),(211,1),(212,1),(213,1),(214,1),(215,63),(216,1),(217,1),(218,1),(219,1);
/*!40000 ALTER TABLE `revision_comment_temp` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:52
