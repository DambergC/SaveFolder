-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log_search`
--

DROP TABLE IF EXISTS `log_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_search` (
  `ls_field` varbinary(32) NOT NULL,
  `ls_value` varbinary(255) NOT NULL,
  `ls_log_id` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ls_field`,`ls_value`,`ls_log_id`),
  KEY `ls_log_id` (`ls_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_search`
--

LOCK TABLES `log_search` WRITE;
/*!40000 ALTER TABLE `log_search` DISABLE KEYS */;
INSERT INTO `log_search` VALUES (_binary 'associated_rev_id',_binary '1',1),(_binary 'associated_rev_id',_binary '3',2),(_binary 'associated_rev_id',_binary '5',3),(_binary 'associated_rev_id',_binary '6',4),(_binary 'associated_rev_id',_binary '7',5),(_binary 'associated_rev_id',_binary '8',6),(_binary 'associated_rev_id',_binary '12',7),(_binary 'associated_rev_id',_binary '13',8),(_binary 'associated_rev_id',_binary '14',9),(_binary 'associated_rev_id',_binary '15',11),(_binary 'associated_rev_id',_binary '15',12),(_binary 'associated_rev_id',_binary '16',13),(_binary 'associated_rev_id',_binary '25',15),(_binary 'associated_rev_id',_binary '27',16),(_binary 'associated_rev_id',_binary '29',17),(_binary 'associated_rev_id',_binary '30',18),(_binary 'associated_rev_id',_binary '30',19),(_binary 'associated_rev_id',_binary '37',20),(_binary 'associated_rev_id',_binary '37',21),(_binary 'associated_rev_id',_binary '38',22),(_binary 'associated_rev_id',_binary '38',23),(_binary 'associated_rev_id',_binary '42',24),(_binary 'associated_rev_id',_binary '44',25),(_binary 'associated_rev_id',_binary '45',26),(_binary 'associated_rev_id',_binary '45',27),(_binary 'associated_rev_id',_binary '46',28),(_binary 'associated_rev_id',_binary '46',29),(_binary 'associated_rev_id',_binary '47',30),(_binary 'associated_rev_id',_binary '47',31),(_binary 'associated_rev_id',_binary '50',32),(_binary 'associated_rev_id',_binary '53',33),(_binary 'associated_rev_id',_binary '54',34),(_binary 'associated_rev_id',_binary '55',35),(_binary 'associated_rev_id',_binary '55',36),(_binary 'associated_rev_id',_binary '57',37),(_binary 'associated_rev_id',_binary '57',38),(_binary 'associated_rev_id',_binary '58',39),(_binary 'associated_rev_id',_binary '58',40),(_binary 'associated_rev_id',_binary '59',41),(_binary 'associated_rev_id',_binary '59',42),(_binary 'associated_rev_id',_binary '60',43),(_binary 'associated_rev_id',_binary '61',44),(_binary 'associated_rev_id',_binary '62',45),(_binary 'associated_rev_id',_binary '62',46),(_binary 'associated_rev_id',_binary '63',47),(_binary 'associated_rev_id',_binary '63',48),(_binary 'associated_rev_id',_binary '64',49),(_binary 'associated_rev_id',_binary '64',50),(_binary 'associated_rev_id',_binary '65',51),(_binary 'associated_rev_id',_binary '67',52),(_binary 'associated_rev_id',_binary '67',53),(_binary 'associated_rev_id',_binary '68',55),(_binary 'associated_rev_id',_binary '75',56),(_binary 'associated_rev_id',_binary '76',57),(_binary 'associated_rev_id',_binary '77',58),(_binary 'associated_rev_id',_binary '77',59),(_binary 'associated_rev_id',_binary '78',60),(_binary 'associated_rev_id',_binary '78',61),(_binary 'associated_rev_id',_binary '79',62),(_binary 'associated_rev_id',_binary '81',63),(_binary 'associated_rev_id',_binary '82',64),(_binary 'associated_rev_id',_binary '83',65),(_binary 'associated_rev_id',_binary '83',66),(_binary 'associated_rev_id',_binary '85',67),(_binary 'associated_rev_id',_binary '85',68),(_binary 'associated_rev_id',_binary '86',69),(_binary 'associated_rev_id',_binary '86',70),(_binary 'associated_rev_id',_binary '87',71),(_binary 'associated_rev_id',_binary '87',72),(_binary 'associated_rev_id',_binary '88',73),(_binary 'associated_rev_id',_binary '88',74),(_binary 'associated_rev_id',_binary '95',75),(_binary 'associated_rev_id',_binary '126',76),(_binary 'associated_rev_id',_binary '139',77),(_binary 'associated_rev_id',_binary '140',78),(_binary 'associated_rev_id',_binary '143',80),(_binary 'associated_rev_id',_binary '144',81),(_binary 'associated_rev_id',_binary '148',82),(_binary 'associated_rev_id',_binary '149',83),(_binary 'associated_rev_id',_binary '149',84),(_binary 'associated_rev_id',_binary '150',85),(_binary 'associated_rev_id',_binary '150',86),(_binary 'associated_rev_id',_binary '151',87),(_binary 'associated_rev_id',_binary '151',88),(_binary 'associated_rev_id',_binary '152',89),(_binary 'associated_rev_id',_binary '152',90),(_binary 'associated_rev_id',_binary '153',91),(_binary 'associated_rev_id',_binary '153',92),(_binary 'associated_rev_id',_binary '154',93),(_binary 'associated_rev_id',_binary '154',94),(_binary 'associated_rev_id',_binary '155',95),(_binary 'associated_rev_id',_binary '156',96),(_binary 'associated_rev_id',_binary '157',97),(_binary 'associated_rev_id',_binary '159',98),(_binary 'associated_rev_id',_binary '160',99),(_binary 'associated_rev_id',_binary '161',100),(_binary 'associated_rev_id',_binary '162',101),(_binary 'associated_rev_id',_binary '162',102),(_binary 'associated_rev_id',_binary '163',103),(_binary 'associated_rev_id',_binary '163',104),(_binary 'associated_rev_id',_binary '164',105),(_binary 'associated_rev_id',_binary '164',106),(_binary 'associated_rev_id',_binary '165',107),(_binary 'associated_rev_id',_binary '165',108),(_binary 'associated_rev_id',_binary '168',109),(_binary 'associated_rev_id',_binary '169',110),(_binary 'associated_rev_id',_binary '170',111),(_binary 'associated_rev_id',_binary '171',112),(_binary 'associated_rev_id',_binary '172',113),(_binary 'associated_rev_id',_binary '173',114),(_binary 'associated_rev_id',_binary '173',115),(_binary 'associated_rev_id',_binary '174',116),(_binary 'associated_rev_id',_binary '174',117),(_binary 'associated_rev_id',_binary '175',118),(_binary 'associated_rev_id',_binary '175',119),(_binary 'associated_rev_id',_binary '176',120),(_binary 'associated_rev_id',_binary '176',121),(_binary 'associated_rev_id',_binary '177',122),(_binary 'associated_rev_id',_binary '177',123),(_binary 'associated_rev_id',_binary '178',124),(_binary 'associated_rev_id',_binary '178',125),(_binary 'associated_rev_id',_binary '179',126),(_binary 'associated_rev_id',_binary '179',127),(_binary 'associated_rev_id',_binary '180',128),(_binary 'associated_rev_id',_binary '180',129),(_binary 'associated_rev_id',_binary '181',130),(_binary 'associated_rev_id',_binary '181',131),(_binary 'associated_rev_id',_binary '182',132),(_binary 'associated_rev_id',_binary '182',133),(_binary 'associated_rev_id',_binary '183',134),(_binary 'associated_rev_id',_binary '183',135),(_binary 'associated_rev_id',_binary '187',136),(_binary 'associated_rev_id',_binary '188',137),(_binary 'associated_rev_id',_binary '189',138),(_binary 'associated_rev_id',_binary '190',139),(_binary 'associated_rev_id',_binary '191',140),(_binary 'associated_rev_id',_binary '192',141),(_binary 'associated_rev_id',_binary '196',143),(_binary 'associated_rev_id',_binary '203',144),(_binary 'associated_rev_id',_binary '204',145),(_binary 'associated_rev_id',_binary '205',146);
/*!40000 ALTER TABLE `log_search` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:54
