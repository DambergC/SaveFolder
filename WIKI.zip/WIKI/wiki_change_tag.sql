-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: wiki
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `change_tag`
--

DROP TABLE IF EXISTS `change_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_tag` (
  `ct_id` int unsigned NOT NULL AUTO_INCREMENT,
  `ct_rc_id` int unsigned DEFAULT NULL,
  `ct_log_id` int unsigned DEFAULT NULL,
  `ct_rev_id` int unsigned DEFAULT NULL,
  `ct_params` blob,
  `ct_tag_id` int unsigned NOT NULL,
  PRIMARY KEY (`ct_id`),
  UNIQUE KEY `change_tag_rc_tag_id` (`ct_rc_id`,`ct_tag_id`),
  UNIQUE KEY `change_tag_log_tag_id` (`ct_log_id`,`ct_tag_id`),
  UNIQUE KEY `change_tag_rev_tag_id` (`ct_rev_id`,`ct_tag_id`),
  KEY `change_tag_tag_id_id` (`ct_tag_id`,`ct_rc_id`,`ct_rev_id`,`ct_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_tag`
--

LOCK TABLES `change_tag` WRITE;
/*!40000 ALTER TABLE `change_tag` DISABLE KEYS */;
INSERT INTO `change_tag` VALUES (1,1,NULL,2,NULL,1),(2,4,3,5,NULL,1),(3,5,4,6,NULL,1),(4,6,5,7,NULL,1),(5,7,6,8,NULL,1),(6,11,7,12,NULL,1),(7,12,8,13,NULL,1),(8,133,NULL,131,NULL,2),(9,196,NULL,193,NULL,1),(10,197,NULL,194,NULL,1),(11,201,NULL,197,NULL,1),(12,203,NULL,199,NULL,1),(13,204,NULL,200,NULL,1),(14,208,145,204,NULL,1),(15,209,146,205,NULL,1),(16,210,NULL,206,NULL,1),(17,211,NULL,207,NULL,1),(18,212,NULL,208,NULL,1),(19,213,NULL,209,NULL,1),(20,214,NULL,210,NULL,1),(21,215,NULL,211,NULL,3),(22,216,NULL,212,NULL,3),(23,217,NULL,213,NULL,1),(24,218,NULL,214,NULL,1),(25,219,NULL,215,NULL,1),(26,220,NULL,216,NULL,1),(27,221,NULL,217,NULL,1),(28,222,NULL,218,NULL,1),(29,223,NULL,219,NULL,1);
/*!40000 ALTER TABLE `change_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-28 10:08:53
