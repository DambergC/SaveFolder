﻿# Define script-level parameters at the top.
param (
    [string]$applicationPath  # Define the application path as a string parameter
)
# Import necessary module for managing IIS. 
Import-Module WebAdministration
 
# Define the site or application to which the header , accepting a parameter for the application path.

try {
    # Attempt to retrieve the IIS application object using the specified path.
    # If the path is incorrect or doesn't exist, an exception will be thrown.
    $applicationPSPath = "IIS:\Sites\$applicationPath"
    $applicationPSPath
    $application = Get-Item $applicationPSPath -ErrorAction Stop
        
    # Output the path of the found application to verify correctness.
    Write-Host "Found site or parent application: $($application.Name)"
        
    # Construct the configuration path based on the application name.
    # This is used to set or check HTTP Headers in the IIS configuration.
    $configPath = "MACHINE/WEBROOT/APPHOST/$($application)"

    # Retrieve existing custom headers for the site.
    # Check if the 'X-Robots-Tag' header is already set.
    $existingHeader = Get-WebConfigurationProperty -Filter "system.webServer/httpProtocol/customHeaders" -PSPath $applicationPSPath -Name collection | Where-Object { $_.name -eq 'X-Robots-Tag' }

    if (-not $existingHeader) {
        # If the header does not exist, add it with value 'noindex'.
        Add-WebConfigurationProperty -Filter "system.webServer/httpProtocol/customHeaders" -PSPath $applicationPSPath -Name "." -Value @{name="X-Robots-Tag";value="noindex"}
            
        # Notify the user that the header has been added.
        Write-Host "Added X-Robots-Tag header to $($application.Name)"
    } else {
        # Notify the user that the header already exists, avoiding duplication.
        Write-Host "X-Robots-Tag header already exists for $($application.Name)"
    }
} catch {
    # Catch block for handling errors such as invalid application paths.
    Write-Host "An error occurred: $($_.Exception.Message)"
}
