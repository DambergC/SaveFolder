USE [CommonStorage]
GO
EXEC sp_MSforeachtable @command1="ALTER TABLE ? NOCHECK CONSTRAINT ALL"
GO
INSERT [CommonStorage].[Application] ([ApplicationId], [Name]) VALUES (N'DASHBOARD', N'Dashboard')
GO
INSERT [CommonStorage].[Application] ([ApplicationId], [Name]) VALUES (N'LOGON', N'Visma Login')
GO
INSERT [CommonStorage].[Application] ([ApplicationId], [Name]) VALUES (N'SecurityServices', N'SecurityServices')
GO
INSERT [CommonStorage].[Tenant] ([TenantId], [Name]) VALUES (N'[Tenant-ID]', N'[TenantName]')
GO
SET IDENTITY_INSERT [CommonStorage].[Setting] OFF 

GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'nonNeptuneLogin', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'serviceProvider.Name', N'LOGON', N'[Tenant-ID]', N'https://win10utv/ViW/Login/')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'serviceProvider.AssertionConsumerServiceUrl', N'LOGON', N'[Tenant-ID]', N'https://win10utv/ViW/Login/Account/SingleSignOn')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'serviceProvider.CertificateThumbprint', N'LOGON', N'[Tenant-ID]', N'[LoginCertThumbprint]')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.Name', N'LOGON', N'[Tenant-ID]', N'http://[IDPURL]/adfs/services/trust')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleSignOnServiceUrl', N'LOGON', N'[Tenant-ID]', N'https://[IDPURL]/adfs/ls/')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleLogoutServiceUrl', N'LOGON', N'[Tenant-ID]', N'https://[IDPURL]/adfs/ls/')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleLogoutServiceResponseUrl', N'LOGON', N'[Tenant-ID]', N'https://[IDPURL]/adfs/ls/')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.CertificateThumbprint', N'LOGON', N'[Tenant-ID]', N'[IDPCertThumbprint]')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.UseEmbeddedCertificate', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SignAuthnRequest', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SignLogoutRequest', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SignLogoutResponse', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleSignOnServiceBinding', N'LOGON', N'[Tenant-ID]', N'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleLogoutServiceBinding', N'LOGON', N'[Tenant-ID]', N'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SignatureMethod', N'LOGON', N'[Tenant-ID]', N'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.WantAssertionSigned', N'LOGON', N'[Tenant-ID]', N'true')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.WantAssertionEncrypted', N'LOGON', N'[Tenant-ID]', N'false')
GO
INSERT [CommonStorage].[Setting] ( [Key], [ApplicationId], [TenantId], [Value]) VALUES (N'partnerIdentityProvider.SingleLogoutServiceUrl', N'LOGON', N'[Tenant-ID]', N'https://[IDPURL]/adfs/ls/')
GO
SET IDENTITY_INSERT [CommonStorage].[Setting] OFF
GO
INSERT [CommonStorage].[ClaimMapping] ([TenantId], [MapFrom], [MapTo]) VALUES (N'[Tenant-ID]', N'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress', N'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress')
GO
EXEC sp_MSforeachtable @command1="ALTER TABLE ? CHECK CONSTRAINT ALL"
GO
