<#
.SYNOPSIS
This script manages a whitelist of instances in a Web.Config file.

.DESCRIPTION
The script supports two actions: 'Add' and 'Remove'. 
The 'Add' action adds a new instance to the Web.Config file, while the 'Remove' action removes an instance from the Web.Config file.

.PARAMETER action
Specifies the action to be performed. It must be either 'Add' or 'Remove'.

.PARAMETER filePath
Specifies the path to the Web.Config file.

.PARAMETER instanceName
Specifies the name of the instance to be added or removed.

.PARAMETER masterFoundationServerUrl
Specifies the URL of the Master Foundation server. It is required when the action is 'Add'.

.PARAMETER foundationServerUrl
Specifies the URL of the Foundation server. It is required when the action is 'Add'.

.PARAMETER personecPServerUrl
Specifies the URL of the Personec P server. It is required when the action is 'Add'.

.PARAMETER logPath
Specifies the path to the log file where the script will write its log messages.

.EXAMPLE
.\manage-whitelist.ps1 -action 'Add' -filePath 'path\to\web.config' -instanceName 'Instance1' -masterFoundationServerUrl 'foundation.server.com' -foundationServerUrl 'foundation.server.com' -personecPServerUrl 'personec.server.com' -logPath 'path\to\log.txt'

.EXAMPLE
.\manage-whitelist.ps1 -action 'Remove' -filePath 'path\to\web.config' -instanceName 'Instance1' -logPath 'path\to\log.txt'
#>



param (
    [Parameter(Mandatory=$true)]
    [string] $logPath,

    [Parameter(Mandatory=$true)]
    [ValidateSet('Add', 'Remove')]
    [string]$action,

    [Parameter(Mandatory=$true)]
    [string]$filePath,

    [Parameter(Mandatory=$true)]
    [string]$instanceName,

    [Parameter(Mandatory=$false)]
    [string]$masterFoundationServerUrl,

    [Parameter(Mandatory=$false)]
    [string]$foundationServerUrl,

    [Parameter(Mandatory=$false)]
    [string]$personecPServerUrl
)

function Write-Log {
    param (
        [string]$Message,
        [string]$LogLevel = "Info"
    )

    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "$Timestamp [$LogLevel] $Message"
    Add-Content -Path $logPath -Value $LogEntry
}

function Add-Instance {
    param (
        [Parameter(Mandatory=$true)]
        [string]$filePath,

        [Parameter(Mandatory=$true)]
        [string]$instanceName,

        [Parameter(Mandatory=$true)]
        [string]$masterFoundationServerUrl,

        [Parameter(Mandatory=$true)]
        [string]$foundationServerUrl,

        [Parameter(Mandatory=$true)]
        [string]$personecPServerUrl
    )

    Write-log "Scheduler Whitelisting: Adding Instance: $instanceName"

    # Construct the URLs
    $urls = @(
        "https://$masterFoundationServerUrl/Admin/Currency/CurrencyExchangeRateFetcher.svc", 
        "https://$foundationServerUrl/$instanceName/Services/QuickReportService/QuickReportService.svc", 
        "https://$foundationServerUrl/$instanceName/Services/SecurityServices/AgentService.svc",
        "https://$personecPServerUrl/IS.Services/SchedulerJobProxy.svc")

    # Load the XML content from the file
    [xml]$xmlContent = Get-Content -Path $filePath

    # Define the namespace manager
    $nsManager = New-Object System.Xml.XmlNamespaceManager($xmlContent.NameTable)
    $nsManager.AddNamespace("ns", $xmlContent.DocumentElement.NamespaceURI)

    # Check if the customerUrls section exists under configSections
    $customerUrlsSectionNode = $xmlContent.configuration.configSections.SelectSingleNode("section[@name='customerUrls']")

    if ($null -eq $customerUrlsSectionNode) {
        # If the customerUrls section does not exist, add it
        $customerUrlsSectionNode = $xmlContent.CreateElement("section")
        $customerUrlsSectionNode.SetAttribute("name", "customerUrls")
        $customerUrlsSectionNode.SetAttribute("type", "Aditro.Foundation.Scheduler.Admin.Helpers.CustomerUrlsSection, Aditro.Foundation.Scheduler.Admin")
        $xmlContent.configuration.configSections.AppendChild($customerUrlsSectionNode) > $null
    }

    # Check if the customerUrls section exists
    $customerUrlsNode = $xmlContent.SelectSingleNode("//ns:customerUrls", $nsManager)

    if ($null -eq $customerUrlsNode) {
        # If the customerUrls section does not exist, add it
        $customerUrlsNode = $xmlContent.CreateElement("customerUrls")
        $xmlContent.configuration.AppendChild($customerUrlsNode) > $null
    }

    # Check if the instance exists
    $instanceNode = $xmlContent.SelectSingleNode("//ns:customerUrls/ns:add[@name='$instanceName']", $nsManager)

    if ($null -eq $instanceNode) {
        # If the instance does not exist, add it
        $instanceNode = $xmlContent.CreateElement("add")
        $instanceNode.SetAttribute("name", $instanceName)
        $customerUrlsNode.AppendChild($instanceNode) > $null
    

        # Add the URLs
        foreach ($url in $urls) {
            $urlNode = $xmlContent.CreateElement("add")
            $urlNode.SetAttribute("value", $url)
            $instanceNode.AppendChild($urlNode)> $null
        }
    } else {
        # If the instance already exists, output a message
        Write-Log "Scheduler Whitelisting: The instance '$instanceName' already exists in the file."
    }

    # Save the updated content back to the file
    $xmlContent.Save($filePath)
    Write-Log "Scheduler Whitelisting: The changes were saved to the file."
}

function Remove-Instance {
    param (
        [Parameter(Mandatory=$true)]
        [string]$filePath,

        [Parameter(Mandatory=$true)]
        [string]$instanceName
    )

    Write-Log "Scheduler Whitelisting: Removing Instance: $instanceName"

    # Load the XML content from the file
    [xml]$xmlContent = Get-Content -Path $filePath

    # Define the namespace manager
    $nsManager = New-Object System.Xml.XmlNamespaceManager($xmlContent.NameTable)
    $nsManager.AddNamespace("ns", $xmlContent.DocumentElement.NamespaceURI)

    # Check if the instance exists
    $instanceNode = $xmlContent.SelectSingleNode("//ns:customerUrls/ns:add[@name='$instanceName']", $nsManager)

    if ($null -ne $instanceNode) {
        # If the instance exists, remove it
        $instanceNode.ParentNode.RemoveChild($instanceNode) > $null

        # Check if there are any other instances
        $otherInstances = $xmlContent.SelectNodes("//ns:customerUrls/ns:add", $nsManager)

        if ($otherInstances.Count -eq 0) {
            # If there are no other instances, remove the customerUrls section
            $customerUrlsNode = $xmlContent.SelectSingleNode("//ns:customerUrls", $nsManager)
            $customerUrlsNode.ParentNode.RemoveChild($customerUrlsNode) > $null

            # Also remove the customerUrls section under configSections
            $customerUrlsSectionNode = $xmlContent.configuration.configSections.SelectSingleNode("section[@name='customerUrls']")
            $xmlContent.configuration.configSections.RemoveChild($customerUrlsSectionNode) > $null
    
        }

        # Save the updated content back to the file
        $xmlContent.Save($filePath)
        Write-Log "Scheduler Whitelisting: The instance '$instanceName' was removed from the file."
    } else {
        # If the instance does not exist, output a message
        Write-Log "Scheduler Whitelisting: The instance '$instanceName' does not exist in the file."
    }
}


# Create logfile
if (-Not (Test-Path -Path $logPath)) {
    # Create the log file if it does not exist
    New-Item -ItemType File -Path $logPath -Force
    Write-Log -Message "Log file created." -logPath $logPath
    } else {
    Write-Log -Message "Log file already exists." -logPath $logPath
    }

# Call the appropriate function based on the action
if ($action -eq 'Add') {
    if ([string]::IsNullOrEmpty($masterFoundationServerUrl)) {
        Write-Log "Scheduler Whitelisting: The masterFoundationServerUrl parameter is required for the Add action." -LogLevel "Error"
        exit 1
    }

    if ([string]::IsNullOrEmpty($foundationServerUrl)) {
        Write-Log "Scheduler Whitelisting: The foundationServerUrl parameter is required for the Add action." -LogLevel "Error"
        exit 1
    }

    if ([string]::IsNullOrEmpty($personecPServerUrl)) {
        Write-Log "Scheduler Whitelisting: The personecPServerUrl parameter is required for the Add action." -LogLevel "Error"
        exit 1
    }
    Add-Instance -filePath $filePath -instanceName $instanceName -masterFoundationServerUrl $masterFoundationServerUrl -foundationServerUrl $foundationServerUrl -personecPServerUrl $personecPServerUrl
} elseif ($action -eq 'Remove') {
    Remove-Instance -filePath $filePath -instanceName $instanceName
}
