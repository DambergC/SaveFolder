var app;
(function (app_1) {
    var menu;
    (function (menu_1) {
        var components;
        (function (components) {
            var AppController = (function () {
                function AppController(menuService, settingsService, $state, $q, $translate, storage, employmentService) {
                    var _this = this;
                    this.menuService = menuService;
                    this.$state = $state;
                    this.$translate = $translate;
                    this.storage = storage;
                    this.employmentService = employmentService;
                    this.menus = [];
                    this.isFooterVisible = true;
                    $q.all([
                        menuService.getMenus().then(function (menus) { return _this.menus = menus; }),
                        settingsService.getSettings().then(function (settings) { return _this.settings = settings; })
                    ]).then(function () { return _this.onDataReady(); });
                }
                Object.defineProperty(AppController.prototype, "selectedMenu", {
                    get: function () {
                        return this.menus && this.menus.filter(function (menu) { return menu.isSelected; })[0];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AppController.prototype, "items", {
                    get: function () {
                        var selectedMenu = this.selectedMenu;
                        return selectedMenu && selectedMenu.items;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AppController.prototype, "navbarRoot", {
                    get: function () {
                        var items = this.items;
                        return items && items.filter(function (item) { return item.isSelectionVisible; })[0];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AppController.prototype, "verticalMenuRoot", {
                    get: function () {
                        var navbarRoot = this.navbarRoot;
                        return navbarRoot && navbarRoot.subItems.filter(function (item) { return item.isSelectionVisible; })[0];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AppController.prototype, "selectedItem", {
                    get: function () {
                        return this.menuService.getSelectedItem();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AppController.prototype, "params", {
                    get: function () {
                        return this.$state.params;
                    },
                    enumerable: true,
                    configurable: true
                });
                AppController.prototype.$onInit = function () {
                };
                AppController.prototype.onDataReady = function () {
                    this.isLoaded = true;
                    //console.log('data ready')
                    this.storage.setSessionId(this.settings.sessionId, this.settings.userLoginName, this.settings.tenantId);
                    this.$translate.use(this.settings.language);
                    this.employmentService.setEmployments(this.settings.employments);
                    window.addEventListener('blur', function (e) {
                        if (document.activeElement == document.querySelector('iframe')) {
                            $('nav.menu-navbar.dropdown.open').click();
                        }
                    });
                };
                AppController.prototype.select = function (item) {
                    this.menuService.select(this.selectedMenu, item);
                };
                AppController.prototype.selectEmployment = function (selectedEmployment) {
                    this.employmentService.selectEmployment(selectedEmployment);
                };
                AppController.$inject = ['MenuService', 'ClientSettingsService', '$state', '$q', '$translate', 'StorageService', 'EmploymentService'];
                return AppController;
            }());
            components.app = {
                controller: AppController,
                templateUrl: menu_1.url.template('app'),
                bindings: {}
            };
        })(components = menu_1.components || (menu_1.components = {}));
    })(menu = app_1.menu || (app_1.menu = {}));
})(app || (app = {}));
