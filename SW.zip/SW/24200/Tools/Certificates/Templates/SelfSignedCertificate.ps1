$certfilepath = "[EXPORTPATH]"     #Where do you want to export the file to?  Include trailing backslash
$certfilename = "[COMMON_NAME]"  #what name would you like for the cert (used for Certificate Name and Exported Filename) [no extension]

$mypwd = ConvertTo-SecureString -String "1234" -Force -AsPlainText

$name = new-object -com "X509Enrollment.CX500DistinguishedName.1"
$name.Encode("CN=" + $certfilename , 0)

# Create a new Private Key
$key = new-object -com "X509Enrollment.CX509PrivateKey.1"
$key.ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
$key.KeySpec = 1
$key.Length = 2048
$key.SecurityDescriptor = "D:PAI(A;;0xd01f01ff;;;SY)(A;;0xd01f01ff;;;BA)(A;;0x80120089;;;NS)"
$key.MachineContext = 1
$key.Create()

$serverauthoid = new-object -com "X509Enrollment.CObjectId.1"
$serverauthoid.InitializeFromValue("1.3.6.1.5.5.7.3.2")
$ekuoids = new-object -com "X509Enrollment.CObjectIds.1"
$ekuoids.add($serverauthoid)
$ekuext = new-object -com "X509Enrollment.CX509ExtensionEnhancedKeyUsage.1"
$ekuext.InitializeEncode($ekuoids)

# Create a new Certificate from key
$cert = new-object -com "X509Enrollment.CX509CertificateRequestCertificate.1"
$cert.InitializeFromPrivateKey(2, $key, "")
$cert.Subject = $name
$cert.Issuer = $cert.Subject
$cert.NotBefore = get-date
$cert.NotAfter = $cert.NotBefore.AddDays(2900)
$cert.X509Extensions.Add($ekuext)
$cert.Encode()

# Create Enrollement; Install Certifiate
$enrollment = new-object -com "X509Enrollment.CX509Enrollment.1"
$enrollment.InitializeFromRequest($cert)
$certdata = $enrollment.CreateRequest(0)
$enrollment.InstallResponse(2, $certdata, 0, "")

# Let user know the certificate is now installed
Write "The following <$certfilename> certs are now installed..."
dir -recurse cert:\localmachine\My | Where-Object { $_.Subject -eq ("CN=" + $certfilename)} | Format-Table subject, thumbprint, notbefore -AutoSize

# Get the thumbprint from the last created certificate of the name we just created - so we can export it to a file
$thumbprint=(dir cert:\localmachine\My -recurse | where {$_.Subject -match "CN=" + $certfilename} | Select-Object -Last 1).thumbprint
Write  "Exporting cert:\LocalMachine\My\$thumbprint to $certfilepath$certfilename.cer ... "
dir cert:\localmachine\My -recurse | where {$_.thumbprint -match $thumbprint} # Display the certificate we will be exporting

# Do the export - This is the PUBLIC key
$filelocation = $certfilepath ; $filelocation += $certfilename; $filelocation +=(".cer") # Concatinate the destination filename and path

# Export-PfxCertificate -FilePath $filelocation -Cert cert:\localmachine\My\$thumbprint -Password $mypwd
Export-certificate -FilePath $filelocation -Cert cert:\localmachine\My\$thumbprint
Write "The certificate that was just installed/exported is: cert:\LocalMachine\My\$thumbprint $filelocation"


