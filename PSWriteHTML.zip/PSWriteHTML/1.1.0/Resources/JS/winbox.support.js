﻿function showWinBox(options) {
    new WinBox(options)
}