﻿<#
-------------------------------------------------------------------------------------------------------------------------
.Synopsis
   Generate htmlpage with Devices and Maintenance Windows
.DESCRIPTION
   Script to be run as schedule task on siteserver. 

   The script generate a html-page and if you use the send-mailkitmessage it will send a mail
   to a group of administrators with info about the Maintenace Windows for a devices in a 
   collection.
.EXAMPLE
   Send-DeviceMaintenanceWindows.ps1

.DISCLAIMER
All scripts and other Powershell references are offered AS IS with no warranty.
These script and functions are tested in my environment and it is recommended that you test these scripts in a test environment before using in your production environment.
-------------------------------------------------------------------------------------------------------------------------
#>

<#
	===========================================================================
	Values needed to be updated before running the script
	===========================================================================
#>
$scriptversion = '1.0'
$scriptname = $MyInvocation.MyCommand.Name

$dbserver = 'vntsql0299'

$SMTP = 'smtp.kvv.se'
$MailFrom = 'no-reply@kvv.se'
$MailTo1 = 'christian.damberg@kriminalvarden.se'
$MailTo2 = 'christian.damberg@cygate.se'
#$mailto3 = 'Julia.Hultkvist@kriminalvarden.se'
#$mailto4 = 'Christian.Brask@kriminalvarden.se'
#$mailto5 = 'lars.garlin@kriminalvarden.se'
#$MailTo6 = 'sockv@kriminalvarden.se'
#$mailto7 = 'Tim.Gustavsson@kriminalvarden.se'
$MailPortnumber = '25'
$MailCustomer = 'Kriminalvården - IT'
$emailsubject = "Rapport - Clienthealth diskutrymme"

$Logfile = "G:\Scripts\Logfiles\ClientHealth.log"
function Write-Log
{
Param ([string]$LogString)
$Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
$LogMessage = "$Stamp $LogString"
Add-content $LogFile -value $LogMessage
}



<#
	===========================================================================
	Powershell modules needed in the script
	===========================================================================

	Send-MailkitMessage - https://github.com/austineric/Send-MailKitMessage

	pswritehtml - https://github.com/EvotecIT/PSWriteHTML

	PatchManagementSupportTools - Created by Christian Damberg, Cygate
	https://github.com/DambergC/PatchManagement/tree/main/PatchManagementSupportTools

	DON´T EDIT!!!DON´T EDIT!!!DON´T EDIT!!!DON´T EDIT!!!DON´T EDIT!!!DON´T EDIT!!!
#>

#region modules

if (-not (Get-Module -name send-mailkitmessage))
{
	#Install-Module send-mailkitmessage -ErrorAction SilentlyContinue
	Import-Module send-mailkitmessage
}


if (-not (Get-Module -name PSWriteHTML))
{
	#Install-Module PSWriteHTML -ErrorAction SilentlyContinue
	Import-Module PSWriteHTML
}

if (-not (Get-Module -name PatchManagementSupportTools))
{
	#Install-Module PatchManagementSupportTools -ErrorAction SilentlyContinue
	Import-Module PatchManagementSupportTools
}


#endregion
$resultColl =@()

$query = "SELECT Hostname,LastLoggedOnUser,OSDiskFreeSpace FROM dbo.Clients WHERE OSDiskFreeSpace <= '20'"
            
$data = Invoke-Sqlcmd -ServerInstance $dbserver -Database ClientHealth -Query $query 

$Output = EmailBody -FontSize 15px -FontFamily 'Calibri' -BackGroundColor lightgray -Color yellow {
            EmailTable -DataTable $data -ExcludeProperty "RowError", "RowState", "Table","ItemArray", "HasErrors" -HideFooter -Style compact -AutoSize
            EmailTable -DataTable $data -ExcludeProperty "RowError", "RowState", "Table","ItemArray", "HasErrors" -HideFooter -Style compact -AutoSize
    }

#Save-HTML -FilePath $PSScriptRoot\Output\TestBody.html -ShowHTML -HTML $Output



#use secure connection if available ([bool], optional)
$UseSecureConnectionIfAvailable = $false

#authentication ([System.Management.Automation.PSCredential], optional)
$Credential = [System.Management.Automation.PSCredential]::new("Username", (ConvertTo-SecureString -String "Password" -AsPlainText -Force))

#SMTP server ([string], required)
$SMTPServer = $SMTP

#port ([int], required)
$Port = $MailPortnumber

#sender ([MimeKit.MailboxAddress] http://www.mimekit.net/docs/html/T_MimeKit_MailboxAddress.htm, required)
$From = [MimeKit.MailboxAddress]$MailFrom

#recipient list ([MimeKit.InternetAddressList] http://www.mimekit.net/docs/html/T_MimeKit_InternetAddressList.htm, required)
$RecipientList = [MimeKit.InternetAddressList]::new()
$RecipientList.Add([MimeKit.InternetAddress]$MailTo1)
#$RecipientList.Add([MimeKit.InternetAddress]$MailTo2)
#$RecipientList.Add([MimeKit.InternetAddress]$mailto3)
#$RecipientList.Add([MimeKit.InternetAddress]$MailTo4)
#$RecipientList.Add([MimeKit.InternetAddress]$mailto5)
#$RecipientList.add([MimeKit.InternetAddress]$mailto6)
#$RecipientList.add([MimeKit.InternetAddress]$mailto7)
#cc list ([MimeKit.InternetAddressList] http://www.mimekit.net/docs/html/T_MimeKit_InternetAddressList.htm, optional)
#$CCList=[MimeKit.InternetAddressList]::new()
#$CCList.Add([MimeKit.InternetAddress]$EmailToCC)



#bcc list ([MimeKit.InternetAddressList] http://www.mimekit.net/docs/html/T_MimeKit_InternetAddressList.htm, optional)
$BCCList = [MimeKit.InternetAddressList]::new()
$BCCList.Add([MimeKit.InternetAddress]"BCCRecipient1EmailAddress")


#subject ([string], required)
$Subject = [string]$emailsubject

#text body ([string], optional)
#$TextBody=[string]"TextBody"

#HTML body ([string], optional)
$HTMLBody = [string]$Output

#attachment list ([System.Collections.Generic.List[string]], optional)
$AttachmentList = [System.Collections.Generic.List[string]]::new()
#$AttachmentList.Add("$HTMLFileSavePath")
#$AttachmentList.Add("$CSVFileSavePath")

# Mailparameters
$Parameters = @{
	"UseSecureConnectionIfAvailable" = $UseSecureConnectionIfAvailable
	#"Credential"=$Credential
	"SMTPServer"					 = $SMTPServer
	"Port"						     = $Port
	"From"						     = $From
	"RecipientList"				     = $RecipientList
	#"CCList"=$CCList
	#"BCCList"=$BCCList
	"Subject"					     = $Subject
	#"TextBody"=$TextBody
	"HTMLBody"					     = $HTMLBody
	"AttachmentList"				 = $AttachmentList
}

#endregion

#Region Send Mail

Send-MailKitMessage @Parameters

#endregion

